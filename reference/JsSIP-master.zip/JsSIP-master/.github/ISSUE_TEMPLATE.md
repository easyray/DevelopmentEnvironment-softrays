> Please, do NOT open an issue if you have problems or questions regarding the use of JsSIP. Use the JsSIP Google Group instead:
> 
> https://groups.google.com/forum/#!forum/jssip
> 
> If you have found a bug in the software, or want to propose a new well documented feature or improvement, please delete this text and continue. :)
