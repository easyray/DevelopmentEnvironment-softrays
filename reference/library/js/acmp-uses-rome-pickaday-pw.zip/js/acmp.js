/*#tab-div,.headerbar,.header,#trip-park,.input-style,#trip-date,#trip-time,#trip-destination,#add-new-trip,.button-style,#content1,.content,.content-wrapper,#park-name,#park-address,#park-phone,#park-location,#add-trip,#park-details,#content2,#v-p-list-park,#v-p-list-vehicle,#add-vehicle,#content3,#trip-id,#park-id,#vehicle-id,#wrapper,.pika-single,.is-hidden,.is-bound,.rd-container,.rd-container-attachment,#nav-container,#car-type-name,#car-type-size,#create-car-type,#car-type-id,.edit-link,.m-name,.m-id,#trips-table,.edit-car-park */

var Global_VT,Global_NewVT;

function app_main(){
	var acmp = this;
	
	acmp.init = function(){
		$("#create-car-type").bind("click",acmp.createVT);
		acmp.fetchVT();
		acmp.addTab();
		
	};

	acmp.addTab = function (){
		var H = new tabs(
			document.getElementById("nav-container"),
			{
				"Vehicle Types": document.getElementById("content3"),
				"New Vehicle Type": document.getElementById("content1"),
			},
			{
				"cssFloat":"left",
				"fontFamily":"arial",
				"fontSize": "20px",
				"marginRight": "40px",
				"marginLeft": "20px",
				"backgroundColor": "#ddf",
				"padding":"10px",
				"borderRadius":"5px"
				
			}
			
		);
		
		H.show();
	};
	
	acmp.editVT = function (){
		
		var Nm,Id,Np,Lst;
		
		Lst = $(this).nextAll();
		Nm = Lst[0].value;
		Id = Lst[1].value;
		Np = Lst[2].value;
		
		$("#car-type-name").val(Nm);
		$("#car-type-id").val(Id);
		$("#car-type-size").val(Np);
		$("#content1").show();
		$("#content3").hide();
		
		
	};
	
	acmp.createVT = function (){
		var dat = {
			"id": $("#car-type-id").val(),
			"name" : $("#car-type-name").val(), 
			"n-passenger" :$("#car-type-size").val(),
			"action":"create-vehicle"
		};
		
		Global_NewVT = dat;
		console.log(Global_NewVT);
		$.ajax({ 
			data: dat,
			type:"post", 
			url: "php/acmp.php", 
			success: acmp.vt_Created, 
			error: function(a,b,c){ console.log(a+b+c); } 
		});
	
	};
	
	acmp.vt_Created = function(dat){
		/*
		if(Global_NewVT !=''){
			Global_NewVT.id = dat;
			Global_VT[ Global_VT.length ] = Global_NewVT;
			Global_NewVT = '';
		}/* **/
		//acmp.createVTTable(Global_VT);
		acmp.fetchVT();
		$("#car-type-id").val("");
		$("#car-type-name").val("");
		$("#car-type-size").val("");
		$("#content1").hide();
		$("#content3").show();
		

	};
	
	acmp.fetchVT = function(){
		var dat = {
			"action":"fetch-vehicle"
		};

		$.ajax({ 
			data: dat,
			type:"post", 
			url: "php/acmp.php", 
			success: acmp.vt_fetched, 
			error: function(a,b,c){ console.log(a+b+c); } 
		});	
	};
	
	acmp.vt_fetched = function (dat){
		dat = evaluate(dat);
		Global_VT = dat;
		acmp.createVTTable(dat);

	};
	
	
	acmp.createPark = function (){
		var dat = {
			"location" : "#park-location", 
			"Name" : "#park-name", 
			"Address" : "#park-address", 
			"Phone" : "#park-phone",
			"action":"add-park"
			};
	};
	
	acmp.createVTTable = function(dat){
		var str ;
		str = '<table border="1" >';
		for(var i in dat){
			str+= "<tr>";
				str+="<td>";
				str += dat[i].name;
				str+="</td>";
				str+="<td>";
				str += dat[i]["n-passenger"];
				str+="</td>";
				str+="<td>";
				str += '<span class="edit-link">Edit</span>';
				str += '<input type = "hidden" value="'+dat[i].name+'" class="m-name" />';
				str += '<input type = "hidden" value="'+dat[i].id+'" class="m-id" />';
				str += '<input type = "hidden" value="'+dat[i]["n-passenger"]+'" class="m-id" />';
				str+="</td>";				
			str+= "</tr>";
		}
		str += '</table>';
		$("#content2").html(str);

		$(".edit-link").unbind();
		$(".edit-link").bind("click",acmp.editVT);
	};
	
	var evaluate = function(str){
		return window['eval']("("+str+")");
	};
	acmp.init();
}

	app_main();
/*
$(document).ready(
	function(){
		console.log("ready");
		app_main();
	}
);
*/