
(function($){

	$.login = function(options){
		var settings_ = {
			destination  : "",
			processor    : "login.php",
			usernamefield: "#username",
			usernametag  : "username",
			passwordfield: "#password",
			passwordtag  : "password",
			peekbutton   : "",
			messagebox   : "",
			submitbutton : "#loginbutton"
		};
		
		settings_ = $.extend({}, settings_, options);

		

		
		var successFunction = function(dat){
			if(settings_.messagebox !==''){
				if(evaluate(dat) == 1){
					$(settings_.messagebox).html('<span style="color: green"> Login Successful, redirecting </span>');
					document.location.href = settings_.destination;
				}else{
					$(settings_.messagebox).html('<span style="color: red"> Login Successful, redirecting </span>');
				}
				
				window.setTimeout(
					function(){
						$(settings_.messagebox).html('');
					},
					1000
				);
			}
		};
		
		var errorFunction = function(){
			$(settings_.messagebox).html('<span style="color: red">We Could not reach the server </span>');
			window.setTimeout(
				function(){
					$(settings_.messagebox).html('');
				},
				1000
			);
		};
		
		var evaluate = function(str){
			return window["eval"]('('+str+')');
		};
		
		var ajax_params={
			data:{},
			url: settings_.processor,
			type: "post",
			success: successFunction,
			error: errorFunction
		};
		
		var DataMaker = function(){
			this.Attrib  = [];
			this.Value   = [];
			this.Counter = 0;
			
			DM = this;
			
			DM.addItem = function(attr,val){
				DM.Attrib[DM.Counter]   = attr;
				DM.Value [DM.Counter++] = val;
			};
			

			DM.getData = function(){
				
				var str = '{';
			
				for(var counter=0; counter< DM.Counter; counter++){
					if(counter > 0){ 
						str += ',';
					}
					str += ' "'+DM.Attrib[counter]+ '" :'; 
					str += ' "'+DM.Value [counter]+ '"'  ;
				}
				
				str += '}';
				
				return evaluate(str);
			};
		};
		

		$(settings_.submitbutton).bind("click",
			function(){
				var K = new DataMaker();
				
				K.addItem(
				settings_.usernametag, 
				$(settings_.usernamefield).val()
				);
				
				K.addItem(
				settings_.passwordtag,
				$(settings_.passwordfield).val()
				);		
				
			
				ajax_params.data = K.getData();
				
				$.ajax(ajax_params);
			}
		);
		
		var PasswordPeeker = function(passwordfield,peekbutton){
			
			this.InnerText = document.createElement("input");
			
			var PassP = this;
			
			PassP.switchThings = function(){
				//console.log('Hello');
				var Friend = $(passwordfield)[0];
				$(PassP.InnerText).val(Friend.value);
				$(Friend).replaceWith(PassP.InnerText);
				PassP.InnerText = Friend;
			};			
			
			Friend = $(passwordfield)[0];
			$(this.InnerText).attr("class",Friend.className);
			$(this.InnerText).attr("id",Friend.id);
			$(this.InnerText).attr("type",'text');
			
			$(this.peekbutton).bind("mousedown", PassP.switchThings);
			$(this.peekbutton).bind("mouseup"  , PassP.switchThings);
		};
		
		if( settings_.peekbutton !==''){
			new PasswordPeeker(settings_.passwordfield,settings_.peekbutton);
		}

	};
})(jQuery);

	
