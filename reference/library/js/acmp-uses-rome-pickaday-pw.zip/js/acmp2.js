/*#tab-div,.headerbar,.header,#trip-park,.input-style,#trip-date,#trip-time,#trip-destination,#add-new-trip,.button-style,#content1,.content,.content-wrapper,#park-name,#park-address,#park-phone,#park-location,#add-trip,#park-details,#content2,#v-p-list-park,#v-p-list-vehicle,#add-vehicle,#content3,#trip-id,#park-id,#vehicle-id,#wrapper,.pika-single,.is-hidden,.is-bound,.rd-container,.rd-container-attachment,#nav-container,#car-type-name,#car-type-size,#create-car-type,#car-type-id,.edit-link,.m-name,.m-id,#trips-table,.edit-car-park,#vehicle-details,.update-park-vehicle,#park-vehicle-id,#trip-price,#trip-distance
 */

function app_main(){
	var acmp = this;
	
	acmp.init = function(){
		acmp.fetchLocations();
		acmp.fetchPark();
		acmp.fetchVT();
		acmp.setupDatePicker();
		acmp.setupTimePicker();
		acmp.createTabs();
		acmp.fetchAllTrip();
		$("#add-trip").bind("click",acmp.createPark);
		$("#add-vehicle").bind("click",acmp.addVehicle);
		$("#add-new-trip").bind("click",acmp.createTrip);
		$("#v-p-list-park").bind("change",acmp.fetchParkVehicles);
		$("#trip-park").bind("change",acmp.fetchTripParkVehicles);
		
		
	};
	
	acmp.editCarPark = function(){
		var HiddenList = $(this).nextAll();
		
		var Id =HiddenList[0].value, Name =HiddenList[1].value,
		Addr = HiddenList[2].value, Location = HiddenList[3].value,
		Phone = HiddenList[4].value;
		console.log(Phone);
		$("#park-id").val(Id);
		$("#park-name").val(Name);
		$("#park-address").val(Addr);
		$("#park-phone").val(Phone);
		
		var select1 = $("#park-location")[0];
		acmp.resetSelect(select1,Location);
		
	};
	
	acmp.resetSelect= function(sel,val){
		console.log(sel);
		console.log(val);
		for(var i in sel.options){
			if(sel.options[i].value ==val) break;
			console.log(sel.options[i].value);
		}
		i = evaluate(i);
		
		if(typeof i == 'number'){
			sel.selectedIndex = i;
		}else{
			sel.selectedIndex = 0;
		}
		
	};
	acmp.fetchAllTrip = function(){
		var dat = {"action" : "fetch-all-trips"};
		$.ajax({ data:dat, type:"post", url: "php/acmp.php", success: acmp.alltripsFetched, error: function(a,b,c){ console.log(a+b+c); } });
	};
	
	acmp.alltripsFetched = function (dat){
		
		dat = evaluate(dat);
		var len = dat.length;
		var str = '<table border="1" >';
		str +='<tr >';
		str +='<td><strong>Starting From</strong></td>';
		str +='<td><strong>Going To</strong></td>';
		str +='<td><strong>Date and Time</strong></td>';
		str +='<td><strong>Park</strong></td>';
		str +='<td><strong>Vehicle</strong></td>';
		str +='</tr>';
		
		for( var i= 0 ; i< len; i++){
			str +='<tr >';
			str +='<td>'+dat[i].start+'</td>';
			str +='<td>'+dat[i].stop+'</td>';
			str +='<td>'+dat[i].timestam+'</td>';
			str +='<td>'+dat[i].parkname+'</td>';
			str +='<td>'+dat[i].vehicle+'</td>';
			str +='</tr >';
		}
		
		str += '</table>';
		
		$("#trips-table").html(str);
	};
	acmp.createTabs = function (){
		
		var dat = {"Trip":       $("#content1").get(0),"Add Park":   $("#content2").get(0),"Add Vehicle":$("#content3").get(0)};
		
		var styl = 			{
			"cssFloat":"left",
			"fontFamily":"arial",
			"fontSize": "20px",
			"marginRight": "40px",
			"marginLeft": "20px",
			"backgroundColor": "#ddf",
			"padding":"10px",
			"borderRadius":"5px"
		};
		
		var f = new tabs(
		document.getElementById("tab-div"),	dat,styl
		);
		
		f.show();

	};
	acmp.fetchLocations= function (){
		dat ={"action":"fetch-location"};
	$.ajax({ data: dat,type:"post", url: "php/acmp.php", success: acmp.locationsFetched, error: function(a,b,c){ console.log(a+b+c); } });	
	};
	
	acmp.setupDatePicker = function (){
		var picker = new Pikaday({
				format: 'YYYY-MM-DD',
				field: document.getElementById('trip-date'),
				firstDay: 1,
				minDate: new Date(2000, 0, 1),
				maxDate: new Date(2020, 12, 31),
				yearRange: [2000,2020]
				
		});
		
	};
	
	acmp.setupTimePicker = function (){
		rome(document.getElementById("trip-time"),{ date: false });
	};
	acmp.locationsFetched = function (dat){
		acmp.putInSelect(evaluate(dat));
		acmp.tripDestinationList(evaluate(dat));
	};
	
	acmp.putInSelect = function(dat){
		var str ='<select class="input-style" id="park-location">';
		str += '<option>location</option>';
		
		for (var i in dat){
			str += '<option value = "'+dat[i].id+'">'+dat[i].townname+'</option>';
		}
		
		str +='</select>';
		$("#park-location").html(str);
	};

	acmp.tripDestinationList = function(dat){
		var str ='<select class="input-style" id="park-location">';
		str += '<option>Destination</option>';
		
		for (var i in dat){
			str += '<option value = "'+dat[i].id+'">'+dat[i].townname+'</option>';
		}
		
		str +='</select>';
		$("#trip-destination").html(str);
	};
	
	acmp.createPark = function(){
		var dat = {
			"id":$("#park-id").val(),
			"location" : $("#park-location").val(), 
			"Name" : $("#park-name").val(), 
			"Address" : $("#park-address").val(), 
			"Phone" : $("#park-phone").val(),
			"action": "add-park"
		};
		
		$.ajax({ data: dat, type:"post", url: "php/acmp.php", success: acmp.parkCreated, error: function(a,b,c){ console.log(a+b+c); } });
		
	};
	
	acmp.parkCreated = function(dat){
		$("#park-id").val("");
		$("#park-name").val("");
		$("#park-address").val("");
		$("#park-phone").val("");
		
		var select1 = $("#park-location")[0];
		acmp.resetSelect(select1,0);
		
		acmp.fetchPark();
	};
	
	
	acmp.fetchPark = function (){
		var dat = {"action": "fetch-park"};
		$.ajax({"data":dat, type:"post", url: "php/acmp.php", success: parkFetched, error: function(a,b,c){ console.log(a+b+c); } });
	};
	
	acmp.parkFetched = function(dat){
		dat = evaluate(dat);
		str = '';
		str+= 	'<option>Select Park</option>';
		for(var i in dat ){
			str += '<option value="'+dat[i].id+"_"+dat[i].location+'">'+dat[i].parkname+'</option>';
		}
		
		$("#trip-park").html(str);
		
		acmp.createParkTable(dat);
		acmp.createVPAddVList(dat);
	};
	
	acmp.fetchParkVehicles = function (){
		var Id = this.value;
		var dat ={"action":"fetch-park-vehicle","park-id":Id};
		
		$.ajax({ data:dat, type:"post", url: "php/acmp.php", success: acmp.parkVehiclesFetched, error: function(a,b,c){ console.log(a+b+c); } });
		
	};

	acmp.fetchTripParkVehicles = function (){
		var Id = this.value;
		var dat ={"action":"fetch-park-vehicle","park-id":Id};
		
		$.ajax({ data:dat, type:"post", url: "php/acmp.php", success: acmp.tripParkVehiclesFetched, error: function(a,b,c){ console.log(a+b+c); } });
		
	};	
	
	acmp.tripParkVehiclesFetched = function(dat){
		//console.log(dat);
		dat = evaluate(dat);
		
		var str ='<select class="input-style" id="park-location">';
		str += '<option>Vehicle</option>';
		
		for (var i in dat){
			str += '<option value = "'+dat[i].vehicleid+'">'+dat[i].modelname+'</option>';
		}
		str +='</select>';
		$("#trip-vehicle").html(str);	
	};
	acmp.parkVehiclesFetched = function(dat){
		//console.log(dat);
		dat = evaluate(dat);
		var len;
		var str;
		
		if(typeof dat == 'object'){
			len = dat.length;
			str = '<table border="1" >';
			str += "<tr><td><strong>Vehicle</strong></td><td>&nbsp;</td></tr>";
			for(var i =0 ; i<len; i++){
				str+= '<tr>';
				str+= '<td>'+dat[i].modelname+'</td>';
				str+= '<td><span class ="update-park-vehicle">Edit</span>';
				str+= '<input type="hidden" value ="'+dat[i].id+'" />';
				str+= '<input type="hidden" value ="'+dat[i].vehicleid+'" />';
				str+= '<input type="hidden" value ="'+dat[i].parkid+'" />';
				str+= '<input type="hidden" value ="'+dat[i].parkname+'" />';
				str+= '<input type="hidden" value ="'+dat[i].modelname+'" />';
				str+= '<input type="hidden" value ="'+dat[i].location+'" />';
				str+= '</td>';
				str+= '</tr>';
			}
			
			str+= "</table>";
		}else{
			str = "No Vehicles";
		}
		
		$("#vehicle-details").html(str);
		$(".update-park-vehicle").unbind();
		$(".update-park-vehicle").bind("click",updateParkVehicle);
	};
	
	acmp.updateParkVehicle = function (){
		var stuff = $(this).nextAll();
	
		var Id        = stuff[0].value;
		var VehicleId = stuff[1].value;
		var ParkId    = stuff[2].value;
		var ParkName  = stuff[3].value;
		var VehicleName= stuff[4].value;
		var Location   = stuff[5].value;
		
		$("#park-vehicle-id").val(Id);

		var ParkList    = $("#v-p-list-park")[0];
		var VehicleList = $("#v-p-list-vehicle")[0];
		
		acmp.resetSelect(ParkList,ParkId+"_"+Location);
		acmp.resetSelect(VehicleList,VehicleId);
		
	};
	acmp.createParkTable = function(dat){
		//console.log(dat);
		$(".edit-car-park").unbind();
		str = '';
		str+= 	'<table border="1"><tr>';
		str+=   '<td><strong>Park Name</strong></td>';
		str+=   '<td><strong>Address</strong></td>';
		str+=   '<td><strong>Location</strong></td>';
		str+=   '<td><strong>Click to..</strong></td>';
		str+=   '</tr>'; 
		for(var i in dat ){
			str+=   '<tr><td>'+dat[i].parkname+'</td>';
			str+=   '<td>'+dat[i].address+'</td>';
			str+=   '<td>'+dat[i].townname+'</td>';
			str+=	'<td><span class="edit-car-park" style="cursor:pointer" >Edit</span>';
			str+=   '<input type="hidden" value= "'+dat[i].id+'" />';
			str+=   '<input type="hidden" value= "'+dat[i].parkname+'" />';
			str+=   '<input type="hidden" value= "'+dat[i].address+'" />';
			str+=   '<input type="hidden" value= "'+dat[i].location+'" />';
			str+=   '<input type="hidden" value= "'+dat[i].telephone+'" />';
			str+=   '</td>';
			str+=   '</tr>';
		}
		
		str += '</table>';
		
		$("#park-details").html(str);
		$(".edit-car-park").bind("click",acmp.editCarPark);
		
	};
	
	acmp.createVPAddVList = function(dat){
		str = '';
		str+= 	'<option>Select Park</option>';
		for(var i in dat ){
			str += '<option value="'+dat[i].id+"_"+dat[i].location+'">'+dat[i].parkname+'</option>';
		}
		$("#v-p-list-park").html(str);
	};
	
	
	acmp.fetchVT = function(){
		var dat = {
			"action":"fetch-vehicle"
		};

		$.ajax({ 
			data: dat,
			type:"post", 
			url: "php/acmp.php", 
			success: acmp.vt_fetched, 
			error: function(a,b,c){ console.log(a+b+c); } 
		});	
	};
	
	acmp.vt_fetched = function (dat){
		dat = evaluate(dat);
		str = '';
		str+= 	'<option>Select Vehicle Type</option>';
		for(var i in dat ){
			str += '<option value="'+dat[i].id+'">'+dat[i].name+'</option>';
		}
		$("#v-p-list-vehicle").html(str);
	};
	
	acmp.addVehicle = function(){
	
			var dat = {"id":$("#park-vehicle-id").val(),"park-id" : $("#v-p-list-park").val(),
			"vehicle-id" : $("#v-p-list-vehicle").val(),
			"action" : "add-vehicle"};
			$.ajax({"data":dat, type:"post", url: "php/acmp.php", success: acmp.vehicleAdded, error: function(a,b,c){ console.log(a+b+c); } });
	};
	acmp.vehicleAdded = function(dat){
		
		$("#park-vehicle-id").val("");
		
		var ParkList    = $("#v-p-list-park")[0];
		var VehicleList = $("#v-p-list-vehicle")[0];		
		acmp.resetSelect(ParkList,0);
		acmp.resetSelect(VehicleList,0);
	};
	acmp.createTrip = function(){
			var dat = {
				"id":"",
			"park-location" : $("#trip-park").val(),
			"Destination"   : $("#trip-destination").val(),
			"date"     : $("#trip-date").val(), 
			"time"     : $("#trip-time").val(), 
			"distance" : $("#trip-distance").val(), 
			"price"    : $("#trip-price").val(),
			"Vehicle"  : $("#trip-vehicle").val(),
			"action"   : "add-trip"
			};
			$.ajax({"data":dat, type:"post", url: "php/acmp.php", success: acmp.tripAdded, error: function(a,b,c){ console.log(a+b+c); } });
	};
	
	acmp.tripAdded = function(dat){
		//console.log(dat);
		acmp.fetchAllTrip();
	};
	var evaluate = function(str){
		return window['eval']("("+str+")");
	};
	

	acmp.init();
}

app_main();