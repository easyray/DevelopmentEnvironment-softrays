/*#tab-div,.headerbar,.header,#trip-park,.input-style,#trip-date,#trip-time,#trip-destination,#add-new-trip,.button-style,#content1,.content,.content-wrapper,#park-name,#park-address,#park-phone,#park-location,#add-trip,#park-details,#content2,#v-p-list-park,#v-p-list-vehicle,#add-vehicle,#content3,#trip-id,#park-id,#vehicle-id,#wrapper,.pika-single,.is-hidden,.is-bound,.rd-container,.rd-container-attachment,#nav-container,#car-type-name,#car-type-size,#create-car-type,#car-type-id,.edit-link,.m-name,.m-id,#trips-table,.edit-car-park */

function app_main(){
	var acmp = this;
	
	acmp.init = function(){
		acmp.fetchLocations();
		acmp.setupDatePicker();
		$("#book-button").bind("click",acmp.requestBooking);
		//window.setTimeout(acmp.slideOut,1000);
		//window.setTimeout(acmp.slideIn,4000);
	};

	acmp.requestBooking = function(){
		var dat = {
			"action" : "fetch-date-trip", 
		    "date" : $("#trip-date").val(),
			"origin": $("#origin").val(),
			"destination": $("#destination").val()
		};
		$.ajax({ 
			data: dat,
			type:"post", 
			url: "php/acmp.php", 
			success: acmp.dateTripFetched, 
			error: function(a,b,c){ console.log(a+b+c); } 
		});
	};

	
	acmp.dateTripFetched = function(dat){
		
		
		
		dat = evaluate(dat);
		var str,len;
		if(typeof dat == 'object'){
			
			str = '<table border="1" >';
			str+='<tr>';
			str+='<td width="50"><strong>Starting From </strong></td>';
			str+='<td width="50"><strong >Going To</strong></td>';
			str+='<td width="80"><strong>Price</strong></td>';
			str+='<td width="50"><strong>Vehicle</strong></td>';
			str+='<td width="80"><strong>Seats Available</strong></td>';
			str+='<td width="80"><strong>Park</strong></td>';
			str+='<td><strong>--</strong></td>';
			str+='</tr>';

			len = dat.length;
			var avail;

			for( var i= 0 ; i< len; i++){
				avail = evaluate(dat[i].seaters)- evaluate(dat[i].bookings);

				str+='<tr>';
				str+='<td>'+dat[i].townname+'</td>';
				str+='<td>'+dat[i].townname2+'</td>';
				str+='<td> #'+dat[i].price+'</td>';
				str+='<td>'+dat[i].modelname+'</td>';
				str+='<td>'+avail+'</td>';
				str+='<td>'+dat[i].parkname+'</td>';
				str+='<td>'+ ( (avail >0)? '<button class="book2">book</button>' : '')+'</td>';
				str+='</tr>';				
			}
		}else{
			str = "No trips available";
		}
		
		str += '<div class="button-style" style="padding-top:100px" ><button id="close-avail">Close</button></div>';
		$("#close-avail").unbind();
		$(".book-list").html(str);
		$("#close-avail").bind("click",acmp.slideIn);
		acmp.slideOut();
		//{"id":"3","origin":"5","destination":"11","vehicle_type":"3","timestam":"2016-02-19 12:00","modelname":"Mercerdez 234","townname":"Agege","townname2":"Birnin Kebbi","seaters":"5","date":"2016-02-19","time":"12:00","bookings":0}		
	};

	acmp.slideOut = function(){
		$("#content").animate({"margin-left": "-550px"});
		$("#book-box").hide();
		$(".book-list").show();
	};

	acmp.slideIn = function(){
		$("#content").animate({"margin-left": "70px"});
		$("#book-box").show();
		$(".book-list").hide();
	};

	acmp.fetchLocations= function (){
		dat ={"action":"fetch-location"};
	$.ajax({ data: dat,type:"post", url: "php/acmp.php", success: acmp.locationsFetched, error: function(a,b,c){ console.log(a+b+c); } });	
	};

	acmp.locationsFetched = function (dat){
		acmp.putInSelect(evaluate(dat));
	};

	acmp.putInSelect = function(dat){
		var str ='';
		//str += '<option>location</option>';
		
		for (var i in dat){
			str += '<option value = "'+dat[i].id+'">'+dat[i].townname+'</option>';
		}
		
		str +='';
		$("#origin").html('<option>Location</option>'+str);
		$("#destination").html('<option>Destination</option>'+str);
	};

	acmp.setupDatePicker = function (){
		var picker = new Pikaday({
				format: 'YYYY-MM-DD',
				field: document.getElementById('trip-date'),
				firstDay: 1,
				minDate: new Date(2000, 0, 1),
				maxDate: new Date(2020, 12, 31),
				yearRange: [2000,2020]
				
		});
		
	};
	var evaluate = function(str){
		return window['eval']("("+str+")");
	};


	acmp.init();
}

app_main();
