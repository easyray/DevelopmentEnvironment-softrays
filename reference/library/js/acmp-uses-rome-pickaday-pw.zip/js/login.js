	var dat = {
		destination  : "trips.html",
		processor    : "php/login.php",
		usernamefield: "#username",
		usernametag  : "username",
		passwordfield: "#password",
		passwordtag  : "password",
		messagebox   : "#login-mesage",
		submitbutton : "#loginbutton"
	};

	$.login(dat);