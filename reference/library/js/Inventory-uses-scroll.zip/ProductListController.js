ProductListController=function(){
	this.init= function(){},
	this.layoutItem= function(Div, index,Id){},
	this.mouseOverItem= function(){},
	this.mouseOffItem= function(){},
	this.itemSelected= function(Div){},
	this.fetchItemById= function(Id){},
	this.fetchItemBoxById= function(Id){},
	this.addNewItem= function(item){},
	this.updateItem= function(){}
};