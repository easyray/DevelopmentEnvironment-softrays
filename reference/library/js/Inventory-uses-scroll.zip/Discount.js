DStruct = {
    Sales: {"ProductID" : "ProductID", "Quantity" : "Quantity", "Cost" : "Cost", "CartID" : "CartID"}
}
DiscountListController=function(){
	this.createList= function(Id){},
	this.layoutItem= function(Div, index,Id){},
	this.mouseOverItem= function(){},
	this.mouseOffItem= function(){},
	this.itemSelected= function(Div, index, Id){},
	this.fetchItemById= function(Id){},
	this.fetchItemDivById= function(Id){},
	this.addNewItem= function(item){}
};
DiscountModel=function(){
	this.createDiscount= function(dat){},
	this.updateDiscount= function(Id,dat){},
	this.fetchDiscount= function(Id){},
	this.createPrice= function(dat){},
	this.updatePrice= function(dat){}
};

FormController=function(){
	this.init= function(){},
	this.addEditButton= function(button){},
	this.addUpdateButton= function(button){},
	this.addCancelButton= function(button){},
	this.addSubmitButton= function(button){},
	this.addField= function(field){},
	this.disableForm= function(){},
	this.addNewButton= function(button){},
	this.enableForm= function(){},
	this.enableActions= function(){},
	this.disableActions= function(){},
	this.saveFormValues= function(){},
	this.restoreFormValues= function(){},
	this.freezeForm= function(){},
	this.releaseForm= function(){},
	this.emptyForm= function(){},
	this.formValid= function(){},
	this.resetForm1= function(){},
	this.resetForm2= function(){},
	this.Cancel= function(){},
	this.Change= function(){},
	this.hideNewButton= function(){},
	this.showNewButton= function(){}
};

ModuleListController=function(){
	this.createList= function(ProductId){},
	this.layoutItem= function(Div, index,Id){},
	this.mouseOverItem= function(){},
	this.mouseOffItem= function(){},
	this.itemSelected= function(Div, index, Id){},
	this.fetchItemById= function(Id){},
	this.fetchItemDivById= function(Id){},
	this.addNewItem= function(item){}
};

ProductListController=function(){
	this.init= function(){},
	this.layoutItem= function(Div, index,Id){},
	this.mouseOverItem= function(){},
	this.mouseOffItem= function(){},
	this.itemSelected= function(Div){},
	this.fetchItemById= function(Id){},
	this.fetchItemBoxById= function(Id){},
	this.addNewItem= function(item){},
	this.updateItem= function(){}
};

ProductModel=function(){
	this.init= function(){},
	this.timeStamp= function(){},
	this.fetchProduct= function(){},
	this.searchProduct= function(term){},
	this.fetchModule= function(ProductId){},
	this.fetchUniqueModule= function(Id){},
	this.createProduct= function(ProductName,Description){},
	this.updateProduct= function(id, ProductName,Description){},
	this.createModule= function(dat){},
	this.updateModule= function(Id,dat){}
};

	SalesModel=function(){
		this.timeStamp= function(){},
		this.createCart= function(Customer){},
		this.createSales= function(dat,CartID){},
		this.fetchSales = function(){}
	};

	Session = function (){
		this.init = function (){};
		this.createUser = function(dat){};
		this.loginUser = function(username,pwd){};
		this.createSession = function(dat){};
		this.updateSession = function (ID,dat){};
		this.fetchSession = function(){};
	};

	var AppPool = {
		evaluate: function(Str){},		
		createElement: function(Str){}
	};
	

	
	
	CtrlForm1 = new FormController();
	CtrlForm2 = new FormController();
	

	AppPool.ProductModel           = new ProductModel();
	AppPool.DiscountModel          = new DiscountModel();
	AppPool.ProductListController  = new ProductListController();
	AppPool.ModuleListController   = new ModuleListController();
	AppPool.DiscountListController = new DiscountListController();
	AppPool.DiscountModel          = new DiscountModel();
	AppPool.FormController1  = CtrlForm1;
	AppPool.FormController2  = CtrlForm2;
    AppPool.SalesModel       = new  SalesModel();
    AppPool.Session          = new  Session();


/* -----------------------------------------------------
*	Write Code                                          |
------------------------------------------------------- */
AppPool.Session.createUser();

