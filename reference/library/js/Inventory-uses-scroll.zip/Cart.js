Cart=function(){
	this.addItem= function(Name, Id,Id2 ,Qty,Price){},
	this.removeItem= function(Index){},
	this.drawTable= function(){}
};