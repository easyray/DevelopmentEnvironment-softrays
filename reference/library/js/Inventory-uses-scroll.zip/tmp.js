function SalesModel(){

	this.timeStamp = function() {
		var dd  = new Date();
		var ddd = "";
		
		ddd+= 1900 + dd.getYear()+"-"+
		((1 + dd.getMonth()<10)? "0"+(1 + dd.getMonth()):(1 + dd.getMonth()))+"-"+
		((1 + dd.getDate() <10)? "0"+(1 + dd.getDate() ):(1 + dd.getDate() ))+" "+
		
		((dd.getHours()  <10)? "0"+dd.getHours()  : dd.getHours()  )+":"+
		((dd.getMinutes()<10)? "0"+dd.getMinutes(): dd.getMinutes())+":"+
		((dd.getSeconds()<10)? "0"+dd.getSeconds(): dd.getSeconds());
	
		return ddd;
	};
	
	this.createCart = function(Customer){
		query = "INSERT INTO cart(cart.customer)"+
     	"VALUES('"+Customer+"')";
     
	    //console.log(query);
	    recordset = sqlite.exec(query);

		if(recordset){
			return sqlite.insert_id();
		}else{
			return 0;
		}
	};

	this.createSales = function(dat,CartID){
		
		var Tst = this.timeStamp(),Q =1;
		var GenCode ="SR: SL-"+CartID;

		for(var i in dat){
			dat[i] = sqlite.escapeString(dat[i]);
		}
		
		//if( !(CartID = this.createCart(dat.Customer)) ){ return 0; }
		
		query = "INSERT INTO sales(sales.TansactionID, sales.product, sales.Quantity, sales.DiscountType, sales.Cost, sales.cart, sales.TimeStp)"+
		"VALUES('"+GenCode+"' ,'"+dat.ProductID+"' ,'"+dat.Quantity+"' ,'"+Q+"' ,'"+dat.Cost+"' ,'"+CartID+"' ,'"+Tst+"')";

	    //console.log(query);
	    recordset = sqlite.exec(query);

		if(recordset){
			return sqlite.insert_id();
		}else{
			return 0;
		}
	}
}

function getFunctionPrototype(fn){
	var p = fn.prototype.constructor.toString();
	
	
	p  = p.match(/function\s*(\w+)?\s*\((\s*\w+\s*,)*(\s*\w+\s*)?\)/)[0].toString();
	
	p  = p.match(/\((\s*\w+\s*,)*(\s*\w+\s*)?\)/)[0].toString();
	
	return p;
}

Nam = "SalesModel";
Counter = 0;
str = Nam+ "=function(){";
G = new SalesModel();
for(index in G){
	if (typeof G[index] =="function"){
		if(Counter==0){
			str += "\nthis."+index+"= function"+getFunctionPrototype(G[index])+"{}";
			Counter ++;
		}else{
			str += ",\nthis."+index+"= function"+getFunctionPrototype(G[index])+"{}";
		}
	}
}
str += "\n};";

console.log(str);