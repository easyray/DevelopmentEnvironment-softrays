DiscountModel=function(){
	this.createDiscount= function(dat){},
	this.updateDiscount= function(Id,dat){},
	this.fetchDiscount= function(Id){},
	this.createPrice= function(dat){},
	this.updatePrice= function(dat){}
};