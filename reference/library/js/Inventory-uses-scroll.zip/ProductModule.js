function ProductModel(){
	//Constructor
	this.init= function(){
		sqlite.select_db("inventory");
	};


	this.timeStamp = function() {
		var dd  = new Date();
		var ddd = "";
		
		ddd+= 1900 + dd.getYear()+"-"+
		((1 + dd.getMonth()<10)? "0"+(1 + dd.getMonth()):(1 + dd.getMonth()))+"-"+
		((1 + dd.getDate() <10)? "0"+(1 + dd.getDate() ):(1 + dd.getDate() ))+" "+
		
		((dd.getHours()  <10)? "0"+dd.getHours()  : dd.getHours()  )+":"+
		((dd.getMinutes()<10)? "0"+dd.getMinutes(): dd.getMinutes())+":"+
		((dd.getSeconds()<10)? "0"+dd.getSeconds(): dd.getSeconds());
	
		return ddd;
	};
	//Method FetchProduct
	this.fetchProduct = function(){

		var query = "SELECT * FROM Product";
		var row, count = 0;
		var ret = [];
		
		
		recordset = sqlite.exec(query);
		//console.log(recordset);
		
		
		while(row = sqlite.fetch_assoc(recordset)){
			ret[count++] = row;
		}
		
		
		return ret;
	};

	this.searchProduct = function(term){
		try{	
			term = sqlite.escapeString(term)

			var query = "SELECT id, ProductName FROM Product "+
			"WHERE ProductName like '%"+term+"%'";

			var row, count = 0;
			var ret  = [];
			
			recordset = sqlite.exec(query);
			
			while(row = sqlite.fetch_assoc(recordset)){
				ret[count++] = row;
			}
			
			
			return ret;
		}catch(ex){
			console.log(ex);
		}
	};

	this.fetchModule = function(ProductId){
		try{	
			var query = "SELECT * FROM quantitymodule "+
			"WHERE ProductId='"+ProductId+"' ";
			
			var row, count = 0;
			var ret = [];
			
			recordset = sqlite.exec(query);
			
			while(row = sqlite.fetch_assoc(recordset)){
				ret[count++] = row;
			}
			
			
			return ret;
		}catch(ex){
			console.log(ex);
		}
	};

	this.fetchUniqueModule = function(Id){
		try{	
			var query = "SELECT * FROM quantitymodule "+
			"WHERE id='"+Id+"' ";
			
			var row, count = 0;
			var ret = [];
			
			recordset = sqlite.exec(query);
			
			while(row = sqlite.fetch_assoc(recordset)){
				ret[count++] = row;
			}
			
			
			return ret;
		}catch(ex){
			console.log(ex);
		}
	};
	this.createProduct = function(ProductName,Description){
		try{
			var TimeStp = this.timeStamp(), Res;	
			var query = "INSERT INTO Product (ProductName, Description,TimeStp,status) "+
						"VALUES( "+
						"'"+sqlite.escapeString(ProductName)+"', "+
						"'"+sqlite.escapeString(Description)+"', "+
						"'"+TimeStp+"', "+
						"'1'" +	")";
						
			
			Res = sqlite.exec(query);
			if(Res) {

				var pid = sqlite.insert_id();
				console.log("insert id = "+pid);
				return  pid;
			}else{
				return 0;
			}
			
		}catch(er){
			console.log("Error: "+er );
			return 0;
		}
	};

	this.updateProduct = function(id, ProductName,Description) {
		try{
			var Res;	
			var query = "UPDATE Product SET ProductName ='"+
				sqlite.escapeString(ProductName)+"', "+
				"Description = '"+sqlite.escapeString(Description)+"' "+
				"WHERE id ='"+id+"' ";
						
				// */console.log(query); return 0;
				Res = sqlite.exec(query);
				return Res;
		}catch(er){
			console.log("Error: "+er );
			return 0;
		}	
	};

	this.createModule = function(dat){
		try{
			
			var i;
			for(i in dat){
				dat[i] = sqlite.escapeString(dat[i]);
			}

			TimeStp  = this.timeStamp();
	    	query = "INSERT INTO quantitymodule(quantitymodule.ModuleName, quantitymodule.ProductId, quantitymodule.Quantity, quantitymodule.TimeStp, quantitymodule.status)"+
	    	"VALUES('"+dat.ModuleName+"' ,'"+dat.ProductId+"' ,'"+dat.Quantity+"' ,'"+TimeStp+"' ,'"+ 1 +"')";
		    //echo $query;//exit; 
		    
			recordset = sqlite.exec(query) /***/; //**/ OR DIE(mysql_error());
			
			if(recordset){
			 return sqlite.insert_id();
			}else{
			 return 0;
			}			
		}catch(ex){
			console.log("Create Module Error : "+ex);
		}
	};

	this.updateModule = function(Id,dat){
			var i;
			for(i in dat){
				dat[i] = sqlite.escapeString(dat[i]);
			}

			
		query = "UPDATE quantitymodule SET "+
		"ModuleName = '"+dat.ModuleName+"' , "+
		"ProductId  = '"+dat.ProductId+"' , "+
		"Quantity   = '"+dat.Quantity+"'  "+
		"WHERE id = '"+Id+"'";
		
		//echo $query 
		

		recordset = sqlite.exec(query) /***/; //**/ OR DIE(mysql_error());
		
		return recordset;
		
		}	

	//this.init();
}

function getFunctionPrototype(fn){
	var p = fn.prototype.constructor.toString();
	
	
	p  = p.match(/function\s*(\w+)?\s*\((\s*\w+\s*,)*(\s*\w+\s*)?\)/)[0].toString();
	
	p  = p.match(/\((\s*\w+\s*,)*(\s*\w+\s*)?\)/)[0].toString();
	
	return p;
}

Nam = "ProductModel";
Counter = 0;
str = Nam+ "=function(){";
G = new ProductModel();
for(index in G){
	if (typeof G[index] =="function"){
		if(Counter==0){
			str += "\nthis."+index+"= function"+getFunctionPrototype(G[index])+"{}";
			Counter ++;
		}else{
			str += ",\nthis."+index+"= function"+getFunctionPrototype(G[index])+"{}";
		}
	}
}
str += "\n};";

console.log(str);


