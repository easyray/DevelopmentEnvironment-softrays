DiscountListController=function(){
	this.createList= function(Id){},
	this.layoutItem= function(Div, index,Id){},
	this.mouseOverItem= function(){},
	this.mouseOffItem= function(){},
	this.itemSelected= function(Div, index, Id){},
	this.fetchItemById= function(Id){},
	this.fetchItemDivById= function(Id){},
	this.addNewItem= function(item){}
};