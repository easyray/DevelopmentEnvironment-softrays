function getFunctionPrototype(fn){
	var p = fn.prototype.constructor.toString();
	
	
	p  = p.match(/function\s*(\w+)?\s*\((\s*\w+\s*,)*(\s*\w+\s*)?\)/)[0].toString();
	
	p  = p.match(/\((\s*\w+\s*,)*(\s*\w+\s*)?\)/)[0].toString();
	
	return p;
}

Nam = "ProductModel";
Counter = 0;
str = Nam+ "=function(){";
G = new ProductModel();
for(index in G){
	if (typeof G[index] =="function"){
		if(Counter==0){
			str += "\nthis."+index+"= function"+getFunctionPrototype(G[index])+"{}";
			Counter ++;
		}else{
			str += ",\nthis."+index+"= function"+getFunctionPrototype(G[index])+"{}";
		}
	}
}
str += "\n};";

console.log(str);

// or

Nam = "";
Counter = 0;
str = Nam+ " = {";
G   = new ProductModel();
for(index in G){
	if (typeof G[index] =="function"){
		if(Counter==0){
			str += "\nthis."+index+": function"+getFunctionPrototype(G[index])+"{}";
			Counter ++;
		}else{
			str += ",\nthis."+index+": function"+getFunctionPrototype(G[index])+"{}";
		}
	}
}
str += "\n};";

console.log(str);
 
