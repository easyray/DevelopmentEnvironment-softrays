ProductModel=function(){
	this.init= function(){},
	this.timeStamp= function(){},
	this.fetchProduct= function(){},
	this.searchProduct= function(term){},
	this.fetchModule= function(ProductId){},
	this.fetchUniqueModule= function(Id){},
	this.createProduct= function(ProductName,Description){},
	this.updateProduct= function(id, ProductName,Description){},
	this.createModule= function(dat){},
	this.updateModule= function(Id,dat){}
};