ProductModel = {
	init: function(){},
	timeStamp: function(){},
	fetchProduct: function(){},
	searchProduct: function(){},
	fetchModule: function(){},
	fetchUniqueModule: function(){},
	createProduct: function(){},
	updateProduct: function(){},
	createModule: function(){},
	updateModule: function(){}
}

var AppPool= {};

AppPool.ProducModel = ProductModel;

function sss(){
    var dat = [{"id":"1","ProductName":"Panadol","TimeStp":"2016-04-27 05:00:00","Description":"We actually do","status":"1"},{"id":"2","ProductName":"Apple watch","TimeStp":"2016-04-27 05:00:00","Description":"Nice Jewelry","status":"1"},{"id":"3","ProductName":"Android Phones","TimeStp":"2016-04-27 05:00:00","Description":"Very Popular","status":"1"},{"id":"4","ProductName":"Laptop","TimeStp":"2016-04-27 05:00:00","Description":"The choice is yours not mine. Choose","status":"1"},{"id":"6","ProductName":"Forever Land","TimeStp":"2016-05-02 18:33:33","Description":"How do you like it?","status":"1"},{"id":"7","ProductName":"Hand Fan","TimeStp":"2016-05-02 18:48:09","Description":"Real cheap","status":"1"}];
    _dat = AppPool.ProducModel.fetchProduct();
    
    console.log(dat[ind].TimeStp  );
}