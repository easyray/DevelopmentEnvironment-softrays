<?php

	file_put_contents("css/style.css", $_POST['css']);
?>